﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PriceCalculator.Entities;
using PriceCalculator.BL;
using Unity;
using PriceCalculator.Common;

namespace PriceCalculator.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ClientProduct cl1 = new ClientProduct() { Name = "flashdrive", Supply = 'H', Demand = 'H' };
                ClientProduct cl2 = new ClientProduct() { Name = "ssd", Supply = 'H', Demand = 'H' };

                List<ClientProduct> lstClientProds = new List<ClientProduct>();
                lstClientProds.Add(cl1);
                lstClientProds.Add(cl2);

                CompetitiveProduct cp1 = new CompetitiveProduct() { Name = "flashdrive", Competitor = "X", Price = 1.0M };
                CompetitiveProduct cp2 = new CompetitiveProduct() { Name = "ssd", Competitor = "X", Price = 10.0M };
                CompetitiveProduct cp3 = new CompetitiveProduct() { Name = "flashdrive", Competitor = "Y", Price = 0.9M };
                CompetitiveProduct cp4 = new CompetitiveProduct() { Name = "flashdrive", Competitor = "Z", Price = 1.1M };
                CompetitiveProduct cp5 = new CompetitiveProduct() { Name = "ssd", Competitor = "Y", Price = 12.5M };

                List<CompetitiveProduct> lstCompetitiveProds = new List<CompetitiveProduct>();
                lstCompetitiveProds.Add(cp1);
                lstCompetitiveProds.Add(cp2);
                lstCompetitiveProds.Add(cp3);
                lstCompetitiveProds.Add(cp4);
                lstCompetitiveProds.Add(cp5);

                ClientProductBLWrapper cpBLWrapper = new ClientProductBLWrapper();
                if (cpBLWrapper.ComputeProductwiseBestPrice(lstClientProds, lstCompetitiveProds))
                {
                    foreach (var prod in lstClientProds)
                    {
                        System.Console.WriteLine("{0}:{1}", prod.Name, prod.BestPrice == null ? "No Value" : prod.BestPrice.ToString());
                    }

                    System.Console.Read();
                }
                else
                {
                    System.Console.WriteLine("System Error!");
                    System.Console.Read();
                }
            }
            catch (Exception ex)
            {
                Logger.LogException(ex, "Program:Main()");
            }
        }
    }
}
