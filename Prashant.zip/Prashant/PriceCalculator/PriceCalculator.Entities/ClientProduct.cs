﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceCalculator.Entities
{
    public class ClientProduct
    {
        public string Name { get; set; }
        public char Supply { get; set; }
        public char Demand { get; set; }
        public decimal? BestPrice { get; set; }
    }
}
