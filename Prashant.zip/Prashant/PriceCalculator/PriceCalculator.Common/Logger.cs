﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace PriceCalculator.Common
{
    public class Logger
    {
        public enum LogLevel
        {
            Error=1,
            Warning=2,
            Information=3,
            Verbose=4
        }

        public static void LogToFile(string message, string filePath)
        {

        }

        public static void LogException(Exception exp, string source)
        {

        }
    }
}
