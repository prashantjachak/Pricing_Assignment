﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PriceCalculator.Entities;

namespace PriceCalculator.BL
{
    public class ClientProductBL
    {
        PriceStrategy objPriceStat;
        public ClientProductBL(PriceStrategy priceStat)
        {
            objPriceStat = priceStat;
        }

        public decimal GetTheBestPrice(List<CompetitiveProduct> ComptProds)
        {            
            return objPriceStat.GetTheBestPrice(ComptProds);            
        }
    }
}
