﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PriceCalculator.Entities;
using PriceCalculator.BL;
using Unity;
using PriceCalculator.Common;

namespace PriceCalculator.BL
{
    public class ClientProductBLWrapper
    {
        public bool ComputeProductwiseBestPrice(List<ClientProduct> clntProds, List<CompetitiveProduct> comptProds)
        {
            var container = new UnityContainer();

            foreach (var clntProd in clntProds)
            {

                if (clntProd.Supply == 'H' && clntProd.Demand == 'H')
                {
                    container.RegisterType<PriceStrategy, HSupplyHDemand>();
                }
                else if (clntProd.Supply == 'H' && clntProd.Demand == 'L')
                {
                    container.RegisterType<PriceStrategy, HSupplyLDemand>();
                }
                else if (clntProd.Supply == 'L' && clntProd.Demand == 'H')
                {
                    container.RegisterType<PriceStrategy, LSupplyHDemand>();
                }
                else if (clntProd.Supply == 'L' && clntProd.Demand == 'L')
                {
                    container.RegisterType<PriceStrategy, LSupplyLDemand>();
                }
                else
                {
                    Logger.LogException(new Exception("Invalid input data"), "Program:GetProductwiseBestPrice()");
                    return false;
                }                

                var temp = (from x in comptProds
                            where x.Name == clntProd.Name
                            select x).ToList();

                clntProd.BestPrice = container.Resolve<ClientProductBL>().GetTheBestPrice(temp);
            }

            return true;
        }
    }
}
