﻿using System;
using System.Collections.Generic;
using System.Text;
using PriceCalculator.Entities;
using System.Linq;

namespace PriceCalculator.BL
{
    public class LSupplyHDemand : PriceStrategy
    {
        public override decimal GetTheBestPrice(List<CompetitiveProduct> comptProds)
        {
            decimal avgPrice = (from x in comptProds select x.Price).Average();
            decimal minPrice = avgPrice / 2;
            decimal maxPrice = avgPrice + (avgPrice / 2);

            //50% less or more price records will not be taken into consideration while calculating the Best price.
            var bestPrice = (from x in comptProds
                             where x.Price >= minPrice && x.Price <= maxPrice
                             select x).Min(x => x.Price);

            //Rule : If Supply is Low and Demand is High, Product is sold at 5 % more than chosen price.
            return (bestPrice + ((bestPrice / 100) * 5));
        }
    }
}
