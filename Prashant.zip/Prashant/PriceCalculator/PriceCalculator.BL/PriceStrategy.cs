﻿using System;
using System.Collections.Generic;
using System.Text;
using PriceCalculator.Entities;
using System.Linq;

namespace PriceCalculator.BL
{
    public abstract class PriceStrategy
    {
        /// <summary>
        /// Get the best price out of different prices by other companies for same product
        /// </summary>
        /// <param name="ComptProds">Price information from different companies for same product</param>
        /// <returns>Price based on supply and demand</returns>
        public abstract decimal GetTheBestPrice(List<CompetitiveProduct> ComptProds);

    }
}
