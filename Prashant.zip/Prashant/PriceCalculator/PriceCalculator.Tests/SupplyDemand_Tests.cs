﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using PriceCalculator.Entities;
using PriceCalculator.BL;

namespace PriceCalculator.Tests
{
    public class SupplyDemand_Tests
    {
        PriceStrategy objpriceStat;
        [Fact]
        public void Test_GetTheBestPrice_For_HSupplyHDemand()
        {
            //Arrange data
            var ExpectedResult = 50.0M;

            CompetitiveProduct cp1 = new CompetitiveProduct() { Name = "mp3player", Competitor = "X", Price = 60.0M };           
            CompetitiveProduct cp2 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Y", Price = 20.9M };
            CompetitiveProduct cp3 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Z", Price = 50.0M };


            List<CompetitiveProduct> lstCompetitiveProds = new List<CompetitiveProduct>();
            lstCompetitiveProds.Add(cp1);
            lstCompetitiveProds.Add(cp2);
            lstCompetitiveProds.Add(cp3);

            //    public bool ValidateData(List<CompetitiveProduct> ComptProds)
            //    {
            var result =
            (from ComptProd in lstCompetitiveProds
             group ComptProd by ComptProd.Name into nameGrp
             select nameGrp).ToList().Count;

            //return result == 1 ? true : false;
            //    }

            //Act
            objpriceStat = new HSupplyHDemand();
            //Rule : If Supply is High and Demand is High, Product is sold at same price as chosen price.
            var ActualResult = objpriceStat.GetTheBestPrice(lstCompetitiveProds);

            //Assert
            Assert.Equal(ExpectedResult, ActualResult);

        }

        [Fact]
        public void Test_GetTheBestPrice_For_HSupplyLDemand()
        {
            //Arrange data
            var ExpectedResult = 47.5M;

            CompetitiveProduct cp1 = new CompetitiveProduct() { Name = "mp3player", Competitor = "X", Price = 60.0M };
            CompetitiveProduct cp2 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Y", Price = 20.9M };
            CompetitiveProduct cp3 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Z", Price = 50.0M };


            List<CompetitiveProduct> lstCompetitiveProds = new List<CompetitiveProduct>();
            lstCompetitiveProds.Add(cp1);
            lstCompetitiveProds.Add(cp2);
            lstCompetitiveProds.Add(cp3);

            //Act
            objpriceStat = new HSupplyLDemand();
            //Rule : If Supply is High and Demand is Low, Product is sold at 5 % less than chosen price.
            var ActualResult = objpriceStat.GetTheBestPrice(lstCompetitiveProds);

            //Assert
            Assert.Equal(ExpectedResult, ActualResult);

        }

        [Fact]
        public void Test_GetTheBestPrice_For_LSupplyHDemand()
        {
            //Arrange data
            var ExpectedResult = 52.5M;

            CompetitiveProduct cp1 = new CompetitiveProduct() { Name = "mp3player", Competitor = "X", Price = 60.0M };
            CompetitiveProduct cp2 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Y", Price = 20.9M };
            CompetitiveProduct cp3 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Z", Price = 50.0M };


            List<CompetitiveProduct> lstCompetitiveProds = new List<CompetitiveProduct>();
            lstCompetitiveProds.Add(cp1);
            lstCompetitiveProds.Add(cp2);
            lstCompetitiveProds.Add(cp3);

            //Act
            objpriceStat = new LSupplyHDemand();
            //Rule : If Supply is Low and Demand is High, Product is sold at 5 % more than chosen price.
            var ActualResult = objpriceStat.GetTheBestPrice(lstCompetitiveProds);

            //Assert
            Assert.Equal(ExpectedResult, ActualResult);

        }

        [Fact]
        public void Test_GetTheBestPrice_For_LSupplyLDemand()
        {
            //Arrange data
            var ExpectedResult = 55.0M;

            CompetitiveProduct cp1 = new CompetitiveProduct() { Name = "mp3player", Competitor = "X", Price = 60.0M };
            CompetitiveProduct cp2 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Y", Price = 20.9M };
            CompetitiveProduct cp3 = new CompetitiveProduct() { Name = "mp3player", Competitor = "Z", Price = 50.0M };


            List<CompetitiveProduct> lstCompetitiveProds = new List<CompetitiveProduct>();
            lstCompetitiveProds.Add(cp1);
            lstCompetitiveProds.Add(cp2);
            lstCompetitiveProds.Add(cp3);

            //Act
            objpriceStat = new LSupplyLDemand();
            //Rule : If Supply is Low and Demand is Low, Product is sold at 10 % more than chosen price.
            var ActualResult = objpriceStat.GetTheBestPrice(lstCompetitiveProds);

            //Assert
            Assert.Equal(ExpectedResult, ActualResult);

        }
    }
}
